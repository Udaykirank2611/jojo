#include<pthread.h>
#include<stdio.h>
void add(void *ptr);
void sub(void *ptr);
void mul(void *ptr);
void divi(void *ptr);
struct values{
    int a,b;
};
int main(){
    pthread_t t1,t2,t3,t4;
    struct values w,x,y,z;
    w.a=5;
    w.b=10;
    x.a=10;
    x.b=20;
    y.a=5;
    y.b=20;
    z.a=20;
    z.b=10;
    pthread_create(&t1,NULL,(void *)add,&w);
    pthread_create(&t2,NULL,(void *)sub,&x);
    pthread_create(&t3,NULL,(void *)mul,&y);
    pthread_create(&t4,NULL,(void *)divi,&z);
    pthread_join(t1,NULL);
    pthread_join(t2,NULL);
    pthread_join(t3,NULL);
    pthread_join(t4,NULL);
}
void add(void *ptr){
    struct values *n;
    int res;
    n=(struct values *)ptr;
    res=n->a + n->b;
    printf("The sum of %d and %d is %d\n",n->a,n->b,res);
}
void sub(void *ptr){
    struct values *n;
    int res;
    n=(struct values *)ptr;
    res=n->a - n->b;
    printf("The difference of %d and %d is %d\n",n->a,n->b,res);}
void mul(void *ptr){
    struct values *n;
    int res;
    n=(struct values *)ptr;
    res=n->a * n->b;
    printf("The product of %d and %d is %d\n",n->a,n->b,res);
}
void divi(void *ptr){
    struct values *n;
    int res;
    n=(struct values *)ptr;
    res=n->a / n->b;
    printf("The division of %d and %d is %d\n",n->a,n->b,res);
}