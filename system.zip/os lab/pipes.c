#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
char *msg1="Hello Server";
char *msg2="Hello Client";
int main(){
    char buf[15];
    int pid, p[2],q[2];
    pipe(p);
    pipe(q);
    pid=fork();
    if(pid==0){
        close(p[0]);
        close(q[1]);
        write(p[1],msg1,15);
        read(q[0],buf,15);
        printf("%s\n",buf);
        exit(0);
    }
    else{
        close(p[1]);
        close(q[0]);
        read(p[0],buf,15);
        printf("%s\n",buf);
        write(q[1],msg2,15);
        exit(0);
    }
}