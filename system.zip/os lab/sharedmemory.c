#include<string.h>
#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
int main(){
    char *ptr;
    int shmid,pid;
    shmid=shmget(10,20,IPC_CREAT|0666);
    ptr=(char *)shmat(shmid,(char *)0,0);
    pid=fork();
    if(pid==0){
        strcpy(ptr,"Hello Server");
        sleep(1);
        printf("Server sends %s\n",ptr);
    }
    else{
        sleep(1);
        printf("Client sends %s\n",ptr);
        strcpy(ptr,"Hello CLient");
    }
}