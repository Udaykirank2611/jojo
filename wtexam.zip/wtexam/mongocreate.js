const mongo=require("mongodb")
const mclient=mongo.MongoClient;
let url="mongodb://localhost:27017"
async function connectDB()
{
 try {
 const conn=await mclient.connect(url)
 console.log("Connection to MongoDB success")
 const c=conn.db("test");
 console.log("Connected to test database")
 const std=await c.createCollection("student")
 console.log("Student collection created...")
 const singledoc=await
std.insertOne({"_id":123,"name":"John","marks":60});
 console.log("A Student record inserted...")
 const multidoc=await std.insertMany([
 {"_id":246,"name":"Allen","marks":50},
 {"_id":452,"name":"Syam","marks":70}
 ])
 console.log("Record status="+multidoc.acknowledged)
 console.log("Number of records inserted="+multidoc.insertedCount)
 conn.close();
 } catch (err) {
 console.log("Error="+err.message)
 }
}
connectDB();
