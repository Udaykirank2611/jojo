const mongo=require("mongodb")
const mclient=mongo.MongoClient;
let url="mongodb://localhost:27017"
async function connectDB()
{
 try {
 const conn=await mclient.connect(url)
 console.log("Connection to MongoDB success")
 const c=conn.db("test");
 console.log("Connected to test database")
 const std=await c.collection("student")
 console.log("Student collection opened...")
 const data=await
std.updateOne({"name":"John"},{$set:{"marks":80}})
 console.log("Update status="+data.acknowledged)
 console.log("Number of records updated="+data.modifiedCount)
 conn.close();
 }catch(err)
 {
 console.log("Error="+err)
 }
}
connectDB();